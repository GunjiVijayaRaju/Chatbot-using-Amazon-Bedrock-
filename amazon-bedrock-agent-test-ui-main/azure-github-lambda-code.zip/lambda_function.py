import boto3
import base64
import requests
import os
from urllib.parse import urlparse, parse_qs

# S3 client
s3 = boto3.client('s3')
S3_BUCKET = os.environ['S3_BUCKET']
S3_PREFIX = os.environ.get('S3_PREFIX', '')

def lambda_handler(event, context):
    try:
        url = event.get('url')
        pat = event.get('pat', '')  # Optional for GitHub, required for Azure DevOps

        if not url:
            raise Exception("Missing 'url' in event")

        parsed_url = urlparse(url)

        if 'dev.azure.com' in parsed_url.netloc:
            # === Azure DevOps Path ===
            if not pat:
                raise Exception("Azure DevOps PAT is required in event['pat']")
            parsed = parse_azure_url(url)
            context_data = {'pat': pat}
            if parsed['path'] in ['', '/', None]:
                download_azure_folder({**parsed, 'path': '/'}, context_data)
            elif is_azure_file(parsed, context_data):
                download_azure_file(parsed, context_data)
            else:
                download_azure_folder(parsed, context_data)

        elif 'github.com' in parsed_url.netloc:
            # === GitHub Path ===
            parsed = parse_github_url(url)
            context_data = {'pat': pat}  # Optional
            if parsed['is_file']:
                download_github_file(parsed, context_data)
            else:
                download_github_folder(parsed, context_data)

        else:
            raise Exception("Unsupported URL. Only Azure DevOps and GitHub URLs are supported.")

        return {
            'statusCode': 200,
            'body': f"Successfully processed {url}"
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f"Error: {str(e)}"
        }

# ======================= Azure DevOps Functions =======================

def parse_azure_url(url):
    parsed = urlparse(url)
    parts = parsed.path.strip('/').split('/')
    if len(parts) < 4 or parts[2] != '_git':
        raise Exception("Invalid Azure DevOps URL")

    org, project, _, repo = parts[:4]
    query = parse_qs(parsed.query)
    path = query.get('path', ['/'])[0]
    version = query.get('version', ['refs/heads/main'])[0]
    branch = version.split('/')[-1]
    return {'organization': org, 'project': project, 'repo': repo, 'path': path, 'branch': branch}

def azure_headers(pat):
    return {
        'Authorization': 'Basic ' + base64.b64encode(f":{pat}".encode()).decode(),
        'Accept': 'application/json'
    }

def is_azure_file(parsed, context):
    url = (
        f"https://dev.azure.com/{parsed['organization']}/{parsed['project']}/_apis/git/repositories/"
        f"{parsed['repo']}/items?path={parsed['path']}&versionDescriptor.version={parsed['branch']}&api-version=7.1-preview.1"
    )
    resp = requests.get(url, headers=azure_headers(context['pat']))
    resp.raise_for_status()
    return resp.json().get('gitObjectType') == 'blob'

def download_azure_file(parsed, context):
    url = (
        f"https://dev.azure.com/{parsed['organization']}/{parsed['project']}/_apis/git/repositories/"
        f"{parsed['repo']}/items?path={parsed['path']}&versionDescriptor.version={parsed['branch']}&includeContent=true&api-version=7.1-preview.1"
    )
    resp = requests.get(url, headers=azure_headers(context['pat']))
    resp.raise_for_status()
    content_base64 = resp.json().get('content')
    if not content_base64:
        raise Exception(f"No content in Azure file: {parsed['path']}")
    file_bytes = base64.b64decode(content_base64)
    s3_key = S3_PREFIX.rstrip('/') + '/' + parsed['path'].lstrip('/')
    s3.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=file_bytes)
    print(f"Uploaded Azure file to s3://{S3_BUCKET}/{s3_key}")

def download_azure_folder(parsed, context):
    url = (
        f"https://dev.azure.com/{parsed['organization']}/{parsed['project']}/_apis/git/repositories/"
        f"{parsed['repo']}/items?scopePath={parsed['path']}&recursionLevel=Full&versionDescriptor.version={parsed['branch']}&api-version=7.1-preview.1"
    )
    resp = requests.get(url, headers=azure_headers(context['pat']))
    resp.raise_for_status()
    items = resp.json().get('value', [])
    files = [item for item in items if item['gitObjectType'] == 'blob']
    print(f"Found {len(files)} files in Azure folder {parsed['path']}")
    for item in files:
        file_path = item['path']
        file_url = (
            f"https://dev.azure.com/{parsed['organization']}/{parsed['project']}/_apis/git/repositories/"
            f"{parsed['repo']}/items?path={file_path}&versionDescriptor.version={parsed['branch']}&includeContent=true&api-version=7.1-preview.1"
        )
        file_resp = requests.get(file_url, headers=azure_headers(context['pat']))
        file_resp.raise_for_status()
        content = file_resp.json().get('content')
        if content:
            s3_key = S3_PREFIX.rstrip('/') + '/' + file_path.lstrip('/')
            s3.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=base64.b64decode(content))
            print(f"Uploaded Azure file to s3://{S3_BUCKET}/{s3_key}")

# ======================= GitHub Functions =======================

def parse_github_url(url):
    parsed = urlparse(url)
    parts = parsed.path.strip('/').split('/')
    if len(parts) == 2:
        owner, repo = parts
        branch = get_github_default_branch(owner, repo)
        return {'owner': owner, 'repo': repo, 'branch': branch, 'path': '', 'is_file': False}
    elif len(parts) >= 5 and parts[2] in ['blob', 'tree']:
        owner, repo, mode, branch = parts[:4]
        path = '/'.join(parts[4:])
        is_file = (mode == 'blob')
        return {'owner': owner, 'repo': repo, 'branch': branch, 'path': path, 'is_file': is_file}
    else:
        raise Exception("Invalid GitHub URL")

def github_headers(pat=''):
    headers = {'Accept': 'application/vnd.github.v3+json'}
    if pat:
        headers['Authorization'] = f'token {pat}'
    return headers

def get_github_default_branch(owner, repo):
    url = f"https://api.github.com/repos/{owner}/{repo}"
    resp = requests.get(url, headers=github_headers())
    resp.raise_for_status()
    return resp.json().get('default_branch', 'master')

def download_github_file(parsed, context):
    pat = context.get('pat', '')
    url = f"https://api.github.com/repos/{parsed['owner']}/{parsed['repo']}/contents/{parsed['path']}?ref={parsed['branch']}"
    resp = requests.get(url, headers=github_headers(pat))
    resp.raise_for_status()
    data = resp.json()
    if data['type'] != 'file':
        raise Exception("Expected a file but found something else")
    content = base64.b64decode(data['content'])
    s3_key = S3_PREFIX.rstrip('/') + '/' + parsed['path']
    s3.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=content)
    print(f"Uploaded GitHub file to s3://{S3_BUCKET}/{s3_key}")

def download_github_folder(parsed, context):
    pat = context.get('pat', '')
    def recurse(path):
        api_url = f"https://api.github.com/repos/{parsed['owner']}/{parsed['repo']}/contents/{path}?ref={parsed['branch']}"
        resp = requests.get(api_url, headers=github_headers(pat))
        resp.raise_for_status()
        items = resp.json()
        for item in items:
            if item['type'] == 'file':
                file_resp = requests.get(item['download_url'], headers=github_headers(pat))
                file_resp.raise_for_status()
                s3_key = S3_PREFIX.rstrip('/') + '/' + item['path']
                s3.put_object(Bucket=S3_BUCKET, Key=s3_key, Body=file_resp.content)
                print(f"Uploaded GitHub file to s3://{S3_BUCKET}/{s3_key}")
            elif item['type'] == 'dir':
                recurse(item['path'])
    recurse(parsed['path'])

